export class CreateGuruDto {}
