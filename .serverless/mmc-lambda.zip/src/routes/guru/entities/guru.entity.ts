export class Guru {}
